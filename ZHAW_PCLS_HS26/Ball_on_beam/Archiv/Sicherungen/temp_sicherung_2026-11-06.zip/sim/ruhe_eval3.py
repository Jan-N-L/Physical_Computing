exec(open('ruhe_eval.py').read().split("print('---')")[0])
for kw in ({'ehold':7.0,'erel':12.0,'hold_fix':True}, {'ehold':7.0,'erel':12.0,'vhold':18.0,'hold_fix':True}, {'ehold':6.0,'erel':12.0,'vhold':15.0,'hold_fix':True}, {'ehold':5.0,'erel':12.0,'vhold':15.0,'hold_fix':True}):
    ev('ctrl_kombi', kw=kw)
