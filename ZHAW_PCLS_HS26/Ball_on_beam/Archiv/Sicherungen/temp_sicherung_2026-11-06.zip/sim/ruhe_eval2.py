exec(open('ruhe_eval.py').read().split("print('---')")[0])
for kw in ({}, {'ehold':5.0}, {'ehold':7.0}, {'ehold':7.0,'erel':12.0}, {'ehold':7.0,'erel':12.0,'vhold':18.0}, {'ehold':9.0,'erel':14.0,'vhold':18.0}):
    ev('ctrl_kombi', kw=kw)
