import sys; sys.path.insert(0,'../pico'); import sim, importlib, statistics as st
def ev(modname, n=40, s0=300000, kw=None):
    mod=importlib.import_module(modname); oks=0; Ts=[]; jit=[]; rng=[]
    for i in range(n):
        r=sim.run_one(lambda: mod.Regler(**(kw or {})), s0+i, keep_trace=True)
        T=r['T_true']
        Ts.append(T if T is not None else 30.0)
        if T is None: continue
        oks+=1
        w=[q for q in r['trace'] if T+0.5<=q[0]<=T+3.5]
        if len(w)>2:
            jit.append(sum(abs(w[k+1][4]-w[k][4]) for k in range(len(w)-1))/3.0)
            xs=[q[5] for q in w]; rng.append(max(xs)-min(xs))
    Ts.sort()
    print('%-14s %s Erfolg %d/%d  T med %.1f p90 %.1f | in Ruhe: Servo %.0f °/s, Ball bewegt %.1f mm'%(modname,kw or '',oks,n,Ts[n//2],Ts[int(0.9*n)],st.median(jit) if jit else -1,st.median(rng) if rng else -1))
#for m in ('ctrl_mainpid','ctrl_kombi','ctrl_ruhig'): ev(m)
print('---')
for kw in ({}, {'fein':{'i_max':25.0}}, {'fein':{'i_max':25.0,'ki':0.06}}, {'fein':{'i_max':25.0},'e_nah':25.0}, {'fein':{'i_max':25.0,'kp_fein':0.25,'kp_grob':0.35,'kd':0.18}}):
    ev('ctrl_hybrid', kw=kw)
