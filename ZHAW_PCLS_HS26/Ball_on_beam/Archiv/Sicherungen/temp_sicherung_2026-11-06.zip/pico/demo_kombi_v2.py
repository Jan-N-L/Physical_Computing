# demo_kombi_v2.py: Live-Vorführung Ball on Beam, ruhige Version.
#
# Unterschied zu demo_kombi.py:
#   Im Ziel wird der Servo auf einem festen Haltewinkel EINGEFROREN (wie main.py im "hold"),
#   statt dauernd nachzuregeln. Der Haltewinkel kommt aus dem Modell der MPC und gleicht die
#   schwere Seite des Balls an genau dieser Stelle aus. Losgelassen wird erst, wenn der Ball
#   mehr als 12 mm vom Ziel weg ist oder deutlich rollt (> 40 mm/s).
#   Simulator, 60 Läufe (am echten Aufbau noch nicht geprüft):
#     ruhig:   59/60, Median 5.1 s, Servo in Ruhe 0 °/s,  Ball bewegt sich 2.0 mm
#     schnell: 60/60, Median 3.0 s, Servo in Ruhe 36 °/s, Ball bewegt sich 6.1 mm
#     zum Vergleich demo_kombi.py: Servo in Ruhe 93 °/s, 6.3 mm; main.py: Median 12.9 s, 28 °/s
#
# Ablauf: Ball (Punkt waagrecht zu dir) auf die Schiene legen -> Start automatisch.
#         "RUHE nach x.x s" = 1 s durchgehend in ±10 mm um die Mitte (Ballmitte ca. 19 cm).
#         Ball wegnehmen -> Schiene waagrecht, warten auf den nächsten Ball.
#
# Auf dem Pico nötig: vl53l0x.py, kennlinie.py, bob_core.py, bob.py, ctrl_mpc.py, ctrl_kombi.py
# Start: diese Datei in VS Code öffnen, MicroPico "Run". Stopp: Ctrl+C.

# ---- Einstellung ------------------------------------------------------------
MODUS = 'ruhig'      # 'ruhig'   = Servo im Ziel fest, Ball liegt still (Standard)
                     # 'schnell' = schneller im Ziel, Servo regelt im Ziel noch etwas nach
AUSGABE = 0.5        # s zwischen zwei Statuszeilen
# -----------------------------------------------------------------------------

import bob
import bob_core as core
import ctrl_kombi

PARAM = {
    'ruhig': dict(ehold=7.0, erel=12.0, vhold=12.0, vrel=40.0, hold_fix=True),
    'schnell': dict(ehold=6.0, erel=12.0, vhold=10.0, hold_fix=True),
}
OFFSET = core.OFFSET


def warte_auf_ball(h, m):
    h.servo(OFFSET)
    print('Warte auf Ball ...')
    n = 0
    x_ref = None
    while True:
        s = h.ping()
        x, ok = m.update(s, 0.03)
        if s >= core.S_LEER:
            n = 0
            x_ref = None
            continue
        if x_ref is None or abs(x - x_ref) > 4:
            x_ref = x
            n = 0
        n += 1
        if n >= 15:                       # ca. 0.45 s ruhig
            return x


def lauf(h):
    m = core.Messung()
    x0 = warte_auf_ball(h, m)
    print('Ball erkannt bei %.0f mm, Start (Modus %s)' % (x0, MODUS))
    reg = ctrl_kombi.Regler(**PARAM[MODUS])
    reg.reset(x0)
    r = core.Ruhe()
    t0 = h.zeit()
    t_last = t0
    t_print = t0
    gemeldet = False
    fail = False
    leer = 0
    while True:
        s = h.ping()
        t = h.zeit()
        dt = t - t_last
        t_last = t
        if dt <= 0:
            dt = 0.029
        leer = leer + 1 if s >= core.S_LEER else 0
        if leer > 15:
            h.servo(OFFSET)
            print('Ball weg')
            return
        x, ok = m.update(s, dt)
        u = reg.step(x, ok, dt)
        h.servo(core.clamp(OFFSET + u, -core.U_ABS, core.U_ABS))
        tt = t - t0
        r.update(x, tt)
        if r.t_ok is not None and not gemeldet:
            print('RUHE nach %.1f s (bei %.0f mm)' % (r.t_ok, x))
            gemeldet = True
        if r.t_ok is None and gemeldet:
            gemeldet = False
            print('Ball hat das Ziel verlassen, regle weiter')
        if t - t_print > AUSGABE:
            t_print = t
            print('t=%5.1f s  x=%5.0f mm  u=%5.1f°  %s' % (tt, x, u, 'HALTEN' if reg.hold else ''))
        if tt > core.T_FAIL and r.t_ok is None and not fail:
            print('Über 30 s: Fail, regle weiter')
            fail = True


def main():
    h = bob.io()
    try:
        while True:
            lauf(h)
    except KeyboardInterrupt:
        h.servo(OFFSET)
        print('Stopp')


main()
