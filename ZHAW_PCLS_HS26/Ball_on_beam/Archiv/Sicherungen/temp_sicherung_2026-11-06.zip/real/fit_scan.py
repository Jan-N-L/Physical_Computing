import numpy as np
from scipy.optimize import least_squares
from scipy.integrate import solve_ivp
D=[]
for l in open('0004_scan.log'):
    if l.startswith('D,'):
        t,s,x,u,ph=l.strip().split(',')[1:]; D.append((float(t),float(x),float(u)))
D=np.array(D); t0=D[0,0]; D[:,0]-=t0
def seg(a,b):
    m=(D[:,0]>=a)&(D[:,0]<=b); return D[m]
S1=seg(10.0,13.2); S2=seg(14.15,25.9)
def simulate(p,S,x0,v0):
    a0,A,C,ph,mu=p
    def f(t,y):
        x,v=y
        return [v, a0 + A*np.sin(2*np.pi*x/C+ph) - mu*np.tanh(v/5)]
    sol=solve_ivp(f,(S[0,0],S[-1,0]),[x0,v0],t_eval=S[:,0],max_step=0.01)
    if sol.y.shape[1]!=len(S): return np.full(len(S),1e3)
    return sol.y[0]
def res(q):
    p=q[:5]; r1=simulate(p,S1,q[5],q[6])-S1[:,1]; r2=simulate(p,S2,q[7],q[8])-S2[:,1]
    return np.concatenate([r1,r2])
best=None
for C in (90,100,110,120,130):
  for ph in np.linspace(0,2*np.pi,6,endpoint=False):
    q0=[50,100,C,ph,25, 8,30, 330,-150]
    try:
        r=least_squares(res,q0,bounds=([-200,0,60,-10,0,-10,-300,250,-600],[300,400,200,20,150,40,400,345,100]),max_nfev=300)
    except Exception as e: continue
    c=np.sqrt(np.mean(r.fun**2))
    if best is None or c<best[0]: best=(c,r.x)
c,q=best
print('rms %.2f mm'%c); print('a0 %.1f A %.1f C %.1f ph %.2f mu %.1f | x0 %.1f v0 %.1f | x0b %.1f v0b %.1f'%tuple(q))
np.save('fit_q.npy',q)
