import numpy as np, math
from scipy.optimize import least_squares
D=[]
for l in open('0004_scan.log'):
    if l.startswith('D,'):
        t,s,x,u,ph=l.strip().split(',')[1:]; D.append((float(t),float(x),float(u)))
D=np.array(D); D[:,0]-=D[0,0]
def seg(a,b):
    m=(D[:,0]>=a)&(D[:,0]<=b); return D[m]
S1=seg(10.0,13.2); S2=seg(14.15,25.9)
def simulate(p,S,x0,v0,dt=0.005):
    a0,A,C,ph,mu=p
    ts=S[:,0]; out=np.empty(len(ts)); t=ts[0]; x=x0; v=v0; k=0; w=2*math.pi/C
    while k<len(ts):
        while t < ts[k]-1e-9:
            a=a0+A*math.sin(w*x+ph)-mu*math.tanh(v/5)
            vm=v+a*dt/2; xm=x+v*dt/2
            am=a0+A*math.sin(w*xm+ph)-mu*math.tanh(vm/5)
            x+=vm*dt; v+=am*dt; t+=dt
            if x>339: x=339; v=-0.3*v
        out[k]=x; k+=1
    return out
def res(q):
    p=q[:5]
    return np.concatenate([simulate(p,S1,q[5],q[6])-S1[:,1], simulate(p,S2,q[7],q[8])-S2[:,1]])
best=None
for C in (90,105,120):
  for ph in np.linspace(0,2*np.pi,4,endpoint=False):
    q0=[50,100,C,ph,25, 8,30, 330,-150]
    r=least_squares(res,q0,bounds=([-200,0,60,-10,0,-10,-300,250,-600],[300,400,200,20,150,40,400,345,100]),max_nfev=150)
    c=np.sqrt(np.mean(r.fun**2))
    print('start C',C,'ph %.1f'%ph,'rms %.2f'%c, 'C %.1f A %.1f a0 %.1f'%(r.x[2],r.x[1],r.x[0]), flush=True)
    if best is None or c<best[0]: best=(c,r.x)
c,q=best
print('BEST rms %.2f mm'%c); print('a0 %.1f A %.1f C %.1f ph %.2f mu %.1f | x0 %.1f v0 %.1f | x0b %.1f v0b %.1f'%tuple(q))
np.save('fit_q.npy',q)
