import sys, itertools, json
sys.path.insert(0,'/home/claude/bob/pico'); sys.path.insert(0,'/home/claude/bob/sim')
import sim, ctrl_mpc as M
base=dict()
grid=[dict(K=K,tpre=tp,dead=dd,mu=mu,mus=mu*1.3) for K in (10.0,13.0,15.0) for tp in (0.05,0.1,0.15) for dd in (0.012,0.06) for mu in (15.0,28.0)]
res=[]
for g in grid:
    r=sim.evaluate(lambda: M.Regler(**g), n=40, seed0=0)['stats']
    sc=r['erfolg']*100 - r['T_median']*5 - r['T_p90']
    res.append((sc,g,r['summary']))
    print(round(sc,1), g, r['summary'], flush=True)
res.sort(key=lambda z:-z[0])
print('TOP'); [print(z[0],z[1],z[2]) for z in res[:5]]
