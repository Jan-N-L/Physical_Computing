"""Rechenzeit pro step in CPython (Mittel über eine echte Simulationsspur)."""
import os, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
BOB = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(BOB, 'sim')); sys.path.insert(0, os.path.join(BOB, 'pico'))
from sim import run_one
import ctrl_mpc


def timing(kw=None, seeds=(0, 1, 2, 3)):
    kw = kw or {}
    xs = []
    for sd in seeds:
        r = run_one(lambda: ctrl_mpc.Regler(**kw), sd, keep_trace=True)
        xs += [(row[2], row[3]) for row in r['trace']]
    reg = ctrl_mpc.Regler(**kw)
    reg.reset(xs[0][0])
    best = 1e9
    for rep in range(5):
        reg.reset(xs[0][0])
        t0 = time.perf_counter()
        for x, ok in xs:
            reg.step(x, ok, 0.0293)
        best = min(best, (time.perf_counter() - t0) / len(xs))
    return best * 1e6


if __name__ == '__main__':
    print('%.1f us pro step (CPython, bestes von 5)' % timing())
