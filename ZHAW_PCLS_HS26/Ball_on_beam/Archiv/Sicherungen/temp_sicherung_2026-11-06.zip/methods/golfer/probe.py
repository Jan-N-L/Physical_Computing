# Hilfsskript: Auswertung und Spur eines Laufs (nur Abstimmen, seed < 100000)
import sys, importlib
sys.path.insert(0, '/home/claude/bob/sim')
sys.path.insert(0, '/home/claude/bob/pico')
from sim import evaluate, run_one
import ctrl_golfer as G


def ev(n=40, seed0=0, show=True, **p):
    importlib.reload(G)
    r = evaluate(lambda: G.Regler(**p), n=n, seed0=seed0)
    if show:
        print(r['summary'])
        print({g: (v['erfolg'], v['n'], v['T_median']) for g, v in r['stats']['pro_start'].items()})
    return r


def trace(seed, start=None, every=1, tmax=8, **p):
    importlib.reload(G)
    reg = [None]
    def mk():
        reg[0] = G.Regler(**p); return reg[0]
    r = run_one(mk, seed, start, keep_trace=True)
    print(r['start'], r['ok_true'], r['T_true'], r['params'])
    for i, row in enumerate(r['trace']):
        if i % every == 0 and row[0] <= tmax:
            print(row)
    return r


if __name__ == '__main__':
    r = ev(int(sys.argv[1]) if len(sys.argv) > 1 else 40)
    for x in r['runs']:
        if not x['ok_true'] or x['T_true'] > 8:
            print(x['seed'], x['start'] if isinstance(x['start'], str) else round(x['start']), x['T_true'], x['params'])
