import sys
from probe import *
import ctrl_golfer as G, sim
def run(seed, start=None, every=3, tmax=12, **p):
    orig=G.Regler.step
    t=[0.0]
    pl=[None]
    def st(self,x,ok,dt):
        u=orig(self,x,ok,dt); t[0]+=dt
        if int(t[0]/dt+0.5)%every==0 and t[0]<tmax: print('%.2f x=%d st=%d v=%d u=%.1f h=%.1f'%(t[0],x,self.state,self.v,u,self.hold))
        return u
    G.Regler.step=st
    r=sim.run_one(lambda: G.Regler(**p),seed,start)
    G.Regler.step=orig
    print(r['T_true'], r['params'])
if __name__=='__main__':
    run(int(sys.argv[1]), None if len(sys.argv)<3 else (sys.argv[2] if not sys.argv[2][0].isdigit() else float(sys.argv[2])))
