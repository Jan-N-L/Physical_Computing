import sys, itertools, json
from probe import ev
# Aufruf: python3 sweep.py '{"kp":[1,1.5,2],"kd":[0.3,0.5]}' [n] [seed0] [basis-json]
grid = json.loads(sys.argv[1]); n = int(sys.argv[2]) if len(sys.argv) > 2 else 40
seed0 = int(sys.argv[3]) if len(sys.argv) > 3 else 0
base = json.loads(sys.argv[4]) if len(sys.argv) > 4 else {}
keys = list(grid)
for vals in itertools.product(*[grid[k] for k in keys]):
    p = dict(base); p.update(zip(keys, vals))
    s = ev(n, seed0, show=False, **p)['stats']
    print(dict(zip(keys, vals)), s['erfolg'], round(s['T_median'], 2), round(s['T_p90'], 2), s['unter_5s'], flush=True)
