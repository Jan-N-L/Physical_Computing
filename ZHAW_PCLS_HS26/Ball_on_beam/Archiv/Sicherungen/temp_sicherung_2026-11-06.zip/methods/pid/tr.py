import os, sys, json
HERE = os.path.dirname(os.path.abspath(__file__)); BOB = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(BOB, "sim")); sys.path.insert(0, os.path.join(BOB, "pico"))
from sim import run_one
import ctrl_pid
p = json.loads(sys.argv[1]); step = int(sys.argv[3]) if len(sys.argv) > 3 else 10
for s in map(int, sys.argv[2].split(',')):
    r = run_one(lambda: ctrl_pid.Regler(**p), s, keep_trace=True)
    print(s, r['start'] if isinstance(r['start'], str) else round(r['start']), r['params'], r['ok_true'], r['T_true'])
    tr = r['trace']
    print('  ' + ' '.join('%.0f/%.0f' % (t[5], t[4]) for t in tr[:900:step]))
