import os, sys, json
HERE = os.path.dirname(os.path.abspath(__file__)); BOB = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(BOB, "sim")); sys.path.insert(0, os.path.join(BOB, "pico"))
from sim import evaluate
import ctrl_pid
def cost(s):
    return 0.5*s['T_median'] + s['T_p90'] + 0.25*s['T_max'] + 10.0*(s['n']-s['erfolg'])/s['n']*40
if __name__ == '__main__':
    n = int(sys.argv[1]); seed0 = int(sys.argv[2])
    for a in sys.argv[3:]:
        p = json.loads(a)
        r = evaluate(lambda: ctrl_pid.Regler(**p), n=n, seed0=seed0)
        ps = r['stats']['pro_start']
        print('%6.1f %s | %s | %s' % (cost(r['stats']), a, r['summary'],
              ' '.join('%s:%d' % (k, v['erfolg']) for k, v in sorted(ps.items()))), flush=True)
