# Diagnose: Tabelle aus einer PD-Regel (Bin-Mitten) -> was kann die Tabellenstruktur?
import sys, tune, sim
cfg = dict(tune.CFG)
if len(sys.argv) > 1:
    import json; cfg.update(json.loads(sys.argv[1]))
kp, kd, kick = float(sys.argv[2]), float(sys.argv[3]), float(sys.argv[4])
def mid(edges, i, lo, hi):
    e = [lo] + list(edges) + [hi]
    return 0.5 * (e[i] + e[i + 1])
tab = bytearray()
us = cfg['U_SET']
for ie in range(len(cfg['E_EDGES']) + 1):
    for iv in range(len(cfg['V_EDGES']) + 1):
        for ist in range(len(cfg['ST_EDGES']) + 1):
            e = mid(cfg['E_EDGES'], ie, 0, 170); v = mid(cfg['V_EDGES'], iv, -250, 250)
            u = -kp * e - kd * v - (kick * ist if e > 8 else 0)
            tab.append(min(range(len(us)), key=lambda a: abs(us[a] - u)))
r = sim.evaluate(tune.make_factory(bytes(tab), cfg), n=40, seed0=0)
print(sys.argv[1:], r['summary'])
