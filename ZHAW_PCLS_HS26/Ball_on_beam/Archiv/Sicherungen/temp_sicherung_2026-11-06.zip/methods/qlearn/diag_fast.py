# Diagnose: Tabelle greedy in FastPlant, Anteil Laeufe mit 1 s Ruhe bis 8 s / 15 s
import random, sys, json, tune, bob_core as core
def fast_eval(tab, cfg, n=60, seed=5, T=15.0):
    rng = random.Random(seed)
    ok8 = ok15 = 0
    for i in range(n):
        x0 = (0.0, core.X_END, rng.uniform(0, 150), rng.uniform(190, 339))[i % 4]
        p = tune.FastPlant(rng, x0)
        m = core.Messung(); m.x = x0
        r = tune.make_factory(tab, cfg)(); r.reset(x0)
        t = 0.0; tin = None; done = None
        while t < T and done is None:
            t0 = p.t; s = p.ping(); dt = p.t - t0; t += dt
            x, okk = m.update(s, dt)
            p.servo(core.OFFSET + r.step(x, okk, dt))
            if abs(p.x - core.MITTE_MM) <= 10:
                tin = t if tin is None else tin
                if t - tin >= 1.0: done = tin
            else: tin = None
        if done is not None:
            ok15 += 1; ok8 += done < 8
    return ok8, ok15, n
if __name__ == '__main__':
    cfg = dict(tune.CFG); cfg.update(json.loads(sys.argv[1]))
    if sys.argv[2] == 'prior':
        tab = tune.prior_tab(cfg)
    else:
        tab, _, _ = tune.train(int(sys.argv[2]), cfg)
    print(sys.argv[1:], fast_eval(tab, cfg))
