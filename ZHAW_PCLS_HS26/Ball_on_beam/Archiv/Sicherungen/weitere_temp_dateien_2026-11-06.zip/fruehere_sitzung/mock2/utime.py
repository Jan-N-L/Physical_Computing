import physik
def sleep_ms(ms): physik.advance(ms/1000)
def ticks_ms(): return int(physik.st['t']*1000)
def ticks_us(): return int(physik.st['t']*1e6)
def ticks_diff(a,b): return a-b
