import math, random
P=dict(c=12, s0=1.9, ar=15, stick=30, bump=3.0)
st=dict(t=0.0, x=150.0, v=0.0, duty=5000)
def servo():
    return (st['duty']-1000)/8000*180-90
def advance(dt):
    n=max(1,int(dt/0.002)); h=dt/n
    for _ in range(n):
        s=servo(); ag=P['c']*(s-P['s0']) + P['bump']*math.sin(2*math.pi*st['x']/60)
        v=st['v']
        if abs(v)<3:
            if abs(ag)<P['stick']: st['v']=0; st['t']+=h; continue
            a=ag-math.copysign(P['ar'],ag)
        else:
            a=ag-math.copysign(P['ar'],v)
        st['v']+=a*h; st['x']+=st['v']*h
        if st['x']<0: st['x']=0; st['v']=-0.3*st['v']
        if st['x']>339: st['x']=339; st['v']=-0.3*st['v']
        st['t']+=h
