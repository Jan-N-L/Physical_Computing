import subprocess, re, random
res=[]
for s0 in (0.5,2.6,3.7):
  for ar in (3,8,15):
    for seed in range(3):
        src=open('physik.py').read()
        src=re.sub(r"s0=[0-9.]*, ar=[0-9.]*", "s0=%s, ar=%s"%(s0,ar), src)
        open('physik.py','w').write(src)
        out=subprocess.run(['python3','-B','-c','import random;random.seed(%d);exec(open("waagrecht_test.py").read())'%seed],capture_output=True,text=True).stdout
        m=re.search(r"Offset\)\s+= ([+-][0-9.]+)",out); r=re.search(r"Rollreibung\s+= ([-0-9.]+)",out)
        t=re.findall(r"(\d+\.\d+) s  ",out)
        res.append((s0,ar,float(m.group(1)) if m else None, float(r.group(1)) if r else None))
        print(s0,ar,seed, m.group(1) if m else out[-300:], r.group(1) if r else '')
err=[abs(a-b) for a,_,b,_ in res if b is not None]
print('max offset err %.2f  mean %.2f'%(max(err),sum(err)/len(err)))
