import random, physik
from kennlinie import to_sensor
class VL53L0X:
    def __init__(s,i2c): pass
    def ping(s):
        physik.advance(0.029)
        x=physik.st['x']
        if random.random()<0.01: return int(to_sensor(x)+random.choice([-80,80]))
        return int(to_sensor(x)+random.gauss(0,1.5+x/150))
