###############################################################################
# Ball on beam: Neigung mit dem Handy messen (phyphox «Neigung»)
###############################################################################
#
# Stellt den Servo nacheinander auf feste Winkel OHNE Offset und hält sie.
# Du misst bei jedem Winkel die Schienenneigung mit dem Handy.
# Daraus folgen:
#   - Offset (Servowinkel, bei dem die Schiene waagrecht ist)
#   - Übersetzung (wie viel Grad Schiene pro Grad Servo)
#
# Handy: phyphox > Neigung > Reiter «Liegend» > Wert «Kippwinkel auf/ab».
# Handy längs auf die Stäbe legen, Ball vorher wegnehmen.
# Pro Winkel: messen, Handy um 180° drehen (Kopf auf die andere Seite),
# nochmals messen. Beide Werte notieren.
###############################################################################

from machine import Pin, PWM
from utime import sleep_ms

WINKEL = (0, 10, -10, 0)    # ° Servo, roh (ohne Offset)
HALTEN_S = 45               # s pro Winkel


def setAngleRaw(angle):
    angle = max(-30, min(30, angle))
    servo.duty_u16(int((angle + 90)/180*8000 + 1000))


servo = PWM(Pin(16))
servo.freq(50)

for w in WINKEL:
    setAngleRaw(w)
    print("\n>> Servo %+d°: Handy messen, um 180° drehen, nochmals messen" % w)
    for rest in range(HALTEN_S, 0, -5):
        print("   noch %d s" % rest)
        sleep_ms(5000)

setAngleRaw(0)
print("\nFertig. Schick mir pro Winkel die beiden Handywerte.")
