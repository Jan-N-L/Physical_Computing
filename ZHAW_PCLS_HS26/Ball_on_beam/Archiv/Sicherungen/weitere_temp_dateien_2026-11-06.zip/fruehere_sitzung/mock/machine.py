import state
class Pin:
    def __init__(s,*a,**k): pass
class I2C:
    def __init__(s,*a,**k): pass
class PWM:
    def __init__(s,*a): pass
    def freq(s,f): pass
    def duty_u16(s,d): state.duty=d
