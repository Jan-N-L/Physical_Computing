import random, state, utime
class VL53L0X:
    def __init__(s,i2c): pass
    def ping(s):
        utime.T[0]+=29
        ang=(state.duty-1000)/8000*180-90
        ball = utime.T[0] > 12000
        x = 256 if ball else 460
        return int(x + ang*1.5 + random.gauss(0,3))
