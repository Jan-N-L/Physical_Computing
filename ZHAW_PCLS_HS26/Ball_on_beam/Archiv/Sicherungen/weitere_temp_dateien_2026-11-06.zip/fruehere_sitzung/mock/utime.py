T=[0]
def sleep_ms(ms): T[0]+=ms
def ticks_ms(): return T[0]
def ticks_diff(a,b): return a-b
