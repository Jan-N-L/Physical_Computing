###############################################################################
# Ball on beam: Winkeltest VL53L0X
###############################################################################
#
# Prüft, ob der Sensorwert vom Kippwinkel abhängt.
# Wenn ja, reicht eine einfache Umrechnungstabelle nicht.
# Braucht nur vl53l0x.py auf dem Pico. Dauer ca. 1 Minute.
#
# Ablauf:
#   1. OHNE Ball starten. Schiene kippt durch alle WINKEL -> misst "leer".
#   2. Ball mit wenig Klebeband auf der 200-mm-Markierung fixieren, Hand weg.
#      Das Skript startet selber, sobald der Ball ruhig liegt.
#      Schiene kippt wieder durch alle WINKEL -> misst "ball".
#
# Ausgabe am Schluss: eine Tabelle. Bitte ganzen Text ab ERGEBNIS kopieren.
###############################################################################

from machine import Pin, I2C, PWM
from vl53l0x import VL53L0X
from utime import sleep_ms, ticks_ms, ticks_diff

OFFSET = 0.5                    # °  waagrecht (wie main.py)
WINKEL = (-10, -5, 0, 5, 10)    # °  relativ zu waagrecht
N = 40                          # Messungen pro Winkel
SERVO_MS = 600                  # Servo fährt und beruhigt sich
STILL = 25                      # mm max. Spanne in 1 s = ruhig
NEW = 25                        # mm Unterschied zu "leer" = Ball liegt drauf
WAIT_MAX = 40000                # ms dann trotzdem messen


def setAngle(angle):
    angle = max(-30, min(30, angle + OFFSET))
    servo.duty_u16(int((angle + 90)/180*8000 + 1000))


tof = VL53L0X(I2C(id=0, scl=Pin(9), sda=Pin(8)))
servo = PWM(Pin(16))
servo.freq(50)
results = []


def median3():
    return sorted([tof.ping(), tof.ping(), tof.ping()])[1]


def sweep(label):
    ref = None
    for w in WINKEL:
        setAngle(w)
        sleep_ms(SERVO_MS)
        vals = [tof.ping() for _ in range(N)]
        vals = [v for v in vals if v < 8000]
        if vals:
            m = sum(vals)/len(vals)
            sd = (sum((v - m)**2 for v in vals)/len(vals))**0.5
        else:
            m = sd = float("nan")
        if w == 0:
            ref = m
        results.append((label, w, m, sd, N - len(vals)))
        print("  %-4s %+3d°: mittel %6.1f  std %4.1f" % (label, w, m, sd))
    setAngle(0)
    return ref


def wait_ball(leer):
    t0 = ticks_ms()
    while ticks_diff(ticks_ms(), t0) < WAIT_MAX:
        win = []
        t1 = ticks_ms()
        while ticks_diff(ticks_ms(), t1) < 1000:
            win.append(median3())
        mid = sorted(win)[len(win)//2]
        if max(win) - min(win) < STILL and abs(mid - leer) > NEW:
            sleep_ms(500)
            return
    print("  Ball nicht erkannt, messe trotzdem")


print("=== Winkeltest startet (OHNE Ball) ===")
leer0 = sweep("leer")
print("\n>> Ball mit Klebeband auf 200-mm-Markierung fixieren, Hand weg")
setAngle(0)
wait_ball(leer0)
ball0 = sweep("ball")

print("\n=== ERGEBNIS (bitte kopieren) ===")
print("art, winkel, mittel, std, ungueltig, abweichung_zu_0grad")
for (label, w, m, sd, bad) in results:
    ref = leer0 if label == "leer" else ball0
    print("%s, %d, %.1f, %.2f, %d, %.1f" % (label, w, m, sd, bad, m - ref))
print("=== Ende ===")
