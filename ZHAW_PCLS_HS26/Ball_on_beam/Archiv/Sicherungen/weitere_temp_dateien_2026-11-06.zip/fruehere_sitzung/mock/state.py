duty=0
