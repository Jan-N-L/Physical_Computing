import io, sys, contextlib, time, threading
import pico_bridge as pb
class FakeSer:
    def __init__(s): s.inb=b""; s.out=b""; s.raw=False; s.code=b""; s.g={}
    def reset_input_buffer(s): s.out=b""
    def write(s,b):
        for c in b:
            c=bytes([c])
            if not s.raw:
                if c==b"\x01": s.raw=True; s.out+=b"raw REPL; CTRL-B to exit\r\n>"
                continue
            if c==b"\x03": continue
            if c==b"\x04":
                if s.code==b"":
                    s.out+=b"OK\r\nMPY: soft reboot\r\nraw REPL; CTRL-B to exit\r\n>"; s.g={}; continue
                code=s.code.decode(); s.code=b""
                buf=io.StringIO(); err=""
                with contextlib.redirect_stdout(buf):
                    try:
                        code=code.replace("import ubinascii","import binascii")
                        exec(code,s.g)
                    except Exception as e: err=repr(e)
                s.out+=b"OK"+buf.getvalue().encode()+b"\x04"+err.encode()+b"\x04>"
            elif c in (b"\r",) and s.code==b"": pass
            else: s.code+=c
    def read(s,n=1):
        r=s.out[:n]; s.out=s.out[n:]; return r
p=pb.Pico.__new__(pb.Pico); p.ser=FakeSer()
p.enter_raw(); p.soft_reset()
open("x.txt","wb").write(bytes(range(256))*20)
print(p.upload("x.txt","/home/claude/bt/y.txt"))
print(open("y.txt","rb").read()==open("x.txt","rb").read())
print(p.exec("print('hallo')\nfor i in range(3): print(i)",5,lambda b: sys.stdout.write(b.decode())))
print(p.exec("1/0",5,None))
