import sys, json
sys.path.insert(0,'/home/claude/bob/sim'); sys.path.insert(0,'/home/claude/bob/pico')
from sim import run_one
import ctrl_fuzzy
P=json.load(open('/tmp/fz/best.json'))
for v in json.loads(sys.argv[1]):
    p=dict(P); p.update(v)
    out=[]
    for s in (22,48,5082,5104,2,31):
        r=run_one(lambda: ctrl_fuzzy.Regler(**p), s)
        out.append(round(r['T_true'],1) if r['ok_true'] else 'F')
    print(v, out)
