import sys, json
sys.path.insert(0,'/home/claude/bob/sim'); sys.path.insert(0,'/home/claude/bob/pico')
from sim import evaluate
import ctrl_fuzzy
P=json.load(open('/tmp/fz/best.json'))
for v in json.loads(sys.argv[1]):
    p=dict(P); p.update(v)
    for s0,n in ((0,80),(5000,200)):
        r=evaluate(lambda: ctrl_fuzzy.Regler(**p), n=n, seed0=s0)
        Ts=[x['T_true'] if x['ok_true'] else 60 for x in r['runs']]
        k=sum(Ts)/len(Ts)+r['stats']['T_p90']+0.25*r['stats']['T_max']
        print(v, s0, round(k,2), r['summary'], flush=True)
