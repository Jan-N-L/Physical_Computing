import sys, json
sys.path.insert(0,'/home/claude/bob/sim'); sys.path.insert(0,'/home/claude/bob/pico')
from sim import evaluate
import ctrl_fuzzy
base = json.loads(sys.argv[1]) if len(sys.argv)>1 else {}
vars_ = json.loads(sys.argv[2]) if len(sys.argv)>2 else [{}]
n = int(sys.argv[3]) if len(sys.argv)>3 else 40
for v in vars_:
    p=dict(base); p.update(v)
    r=evaluate(lambda: ctrl_fuzzy.Regler(**p), n=n, seed0=0)
    ps={k:(d['erfolg'],round(d['T_median'],1)) for k,d in r['stats']['pro_start'].items()}
    print(v, r['summary'], ps, flush=True)
