import sys, json
sys.path.insert(0,'/home/claude/bob/sim'); sys.path.insert(0,'/home/claude/bob/pico')
from sim import evaluate, run_one
import ctrl_fuzzy
p = json.loads(sys.argv[1]); n=int(sys.argv[2]); s0=int(sys.argv[3]) if len(sys.argv)>3 else 0
r=evaluate(lambda: ctrl_fuzzy.Regler(**p), n=n, seed0=s0)
print(r['summary'])
for rr in r['runs']:
    if not rr['ok_true'] or rr['T_true']>8:
        t=run_one(lambda: ctrl_fuzzy.Regler(**p), rr['seed'], keep_trace=True)['trace']
        st=rr['start'] if isinstance(rr['start'],str) else round(rr['start'])
        print(rr['seed'], st, rr['T_true'] and round(rr['T_true'],1), rr['params'])
        print('   ', [(round(q[0],1), round(q[5]), round(q[4],1)) for q in t[::35]][:30])
