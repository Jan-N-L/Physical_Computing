import sys, json
sys.path.insert(0,'/home/claude/bob/sim'); sys.path.insert(0,'/home/claude/bob/pico')
from sim import evaluate
import ctrl_fuzzy
for v in [{}, {"t_pump":0.0}, {"kp0":0.0}, {"ki":0.0}, {"e_zone":0.0,"e_zone_b":1.0}, {"fk_haft_max":9.0,"fk_zeit":6.0}, {"t_back":0.8,"u_back":28,"t_pump":2.5,"du_max":300}]:
    r=evaluate(lambda: ctrl_fuzzy.Regler(**v), n=200, seed0=5000)
    print(json.dumps(v), r['summary'], flush=True)
