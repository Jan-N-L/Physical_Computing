import sys; sys.path.insert(0,'/home/claude/bob/methods/imitation')
import tune as T, ctrl_imitation as ci, pickle
tb,L=T.lerne(**T.END)
pickle.dump(tb,open('/tmp/imi_tb.pkl','wb'))
r=T.sim.evaluate(lambda: ci.Regler(tab=tb), n=80, seed0=0)
print(T.kurz(r)); print(r['stats']['pro_start'])
for x in r['runs']:
    if not x['ok_true'] or x['T_true']>8:
        rr=T.sim.run_one(lambda: ci.Regler(tab=tb), x['seed'], keep_trace=True)
        tr=rr['trace']; xs=[t[5] for t in tr]
        print(x['seed'], x['start'] if isinstance(x['start'],str) else round(x['start']), x['T_true'], x['params'],
              'x(t) jede s:', [round(xs[i]) for i in range(0,len(xs),34)][:16], 'u:', [round(tr[i][4]) for i in range(0,len(tr),34)][:16])
# Ablation ohne s
r2=T.sim.evaluate(lambda: ci.Regler(tab=tb, mit_s=False), n=80, seed0=0); print('ohne s (gleiche Tab):',T.kurz(r2))
