import sys, json
sys.path.insert(0,'/home/claude/bob/sim'); sys.path.insert(0,'/home/claude/bob/pico')
from sim import evaluate
import ctrl_pid
kw = json.loads(sys.argv[1]) if len(sys.argv)>1 else {}
n = int(sys.argv[2]) if len(sys.argv)>2 else 80
s0 = int(sys.argv[3]) if len(sys.argv)>3 else 0
r = evaluate(lambda: ctrl_pid.Regler(**kw), n=n, seed0=s0)
print(r['summary'])
for g,v in r['stats']['pro_start'].items(): print(' ',g, v['erfolg'], '%.2f %.2f'%(v['T_median'], v['T_max']))
bad = sorted(r['runs'], key=lambda q: -(q['T_true'] or 99))[:6]
for q in bad: print('  worst', q['seed'], q['start'] if isinstance(q['start'],str) else round(q['start']), q['T_true'] and round(q['T_true'],2), q['params'], q['verlassen_true'])
