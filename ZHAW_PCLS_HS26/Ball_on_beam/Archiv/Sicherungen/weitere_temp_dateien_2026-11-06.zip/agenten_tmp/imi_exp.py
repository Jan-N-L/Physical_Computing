import sys; sys.path.insert(0,'/home/claude/bob/methods/imitation')
import tune as T, ctrl_imitation as ci
def setS(sn):
    ci.S_N=sn; ci.NS=len(sn)
for sn, kw in [((0.0,0.4,0.8,1.5),dict(dagger=(0.5,0,0,0,0))),
               ((0.0,0.4,0.8,1.5),dict(n_ep=200,dagger=(0.5,0,0))),
               ((0.0,0.3,0.7,1.5,3.0),dict(dagger=(0.5,0,0))),
               ((0.0,0.3,0.7,1.5,3.0),dict(dagger=(0.5,0,0,0,0)))]:
    setS(sn)
    tb,L=T.lerne(**kw)
    print(sn, kw, T.kurz(T.tab_bewerten(tb,80)), flush=True)
