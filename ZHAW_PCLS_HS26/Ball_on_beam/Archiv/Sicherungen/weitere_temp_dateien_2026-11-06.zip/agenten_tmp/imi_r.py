import sys; sys.path.insert(0,'/home/claude/bob/methods/imitation')
import tune as T, ctrl_imitation as ci, pickle
tb=pickle.load(open('/tmp/imi_tb.pkl','rb'))
for kw in (dict(ruetteln=False), dict(), dict(u_zur=25), dict(t_zur=0.5,t_hin=0.8)):
    print(kw, T.kurz(T.sim.evaluate(lambda: ci.Regler(tab=tb,**kw), n=80, seed0=0)), flush=True)
