import sys, json
sys.path.insert(0,'/home/claude/bob/sim'); sys.path.insert(0,'/home/claude/bob/pico')
from sim import run_one
import ctrl_pid
seed=int(sys.argv[1]); kw=json.loads(sys.argv[2]) if len(sys.argv)>2 else {}
regs=[]
def mk():
    r=ctrl_pid.Regler(**kw); regs.append(r); return r
r=run_one(mk, seed, keep_trace=True)
print(r['T_true'], r['params'], r['start'])
step=int(sys.argv[3]) if len(sys.argv)>3 else 3
for i,(t,s,x,ok,u,xt) in enumerate(r['trace']):
    if i%step==0: print('%6.2f %5.1f %5.1f %d %6.2f'%(t,x,xt,ok,u))
