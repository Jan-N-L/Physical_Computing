import sys, math; sys.path.insert(0,'/home/claude/bob/sim'); sys.path.insert(0,'/home/claude/bob/pico')
import sim, ctrl_mpc, json
kw = json.loads(sys.argv[2]) if len(sys.argv)>2 else {}
seed=int(sys.argv[1])
regs=[]
def mk():
    r=ctrl_mpc.Regler(**kw); regs.append(r); return r
# capture plant
orig=sim.Plant.__init__; P=[]
def init(self,*a,**k):
    orig(self,*a,**k); P.append(self)
sim.Plant.__init__=init
# wrap step to log estimates
R=[]
r=sim.run_one(mk, seed, keep_trace=True)
p=P[0]; reg=regs[0]
print('start',r['start'],'ok',r['ok_true'],r['T_true'],r['params'],'circ %.0f wob %.0f'%(p.circ,p.wob[0]))
print('true c0 offset err (mm/s2) ~', round((p.off-1.9)*r['params']['k_servo'],1))
for i,row in enumerate(r['trace']):
    if i%int(sys.argv[3] if len(sys.argv)>3 else 10)==0: print(row)
    if row[0]>float(sys.argv[4] if len(sys.argv)>4 else 12): break
