import sys,json
sys.path.insert(0,'/home/claude/bob/sim'); sys.path.insert(0,'/home/claude/bob/pico')
from sim import run_one
import ctrl_bangbang as C
seed=int(sys.argv[1]); kw=json.loads(sys.argv[2]) if len(sys.argv)>2 else {}
every=int(sys.argv[3]) if len(sys.argv)>3 else 3
tmax=float(sys.argv[4]) if len(sys.argv)>4 else 8
r=run_one(lambda: C.Regler(**kw), seed, keep_trace=True)
print(r['start'], r['T_true'], r['params'])
for i,row in enumerate(r['trace']):
    if i%every==0 and row[0]<tmax: print(row)
