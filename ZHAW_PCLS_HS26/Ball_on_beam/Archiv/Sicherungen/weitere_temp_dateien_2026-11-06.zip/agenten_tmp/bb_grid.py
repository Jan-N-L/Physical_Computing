import sys,json,itertools
sys.path.insert(0,'/home/claude/bob/sim'); sys.path.insert(0,'/home/claude/bob/pico')
from sim import evaluate
import ctrl_bangbang as C
base=json.loads(sys.argv[1]); grid=json.loads(sys.argv[2]); n=int(sys.argv[3]) if len(sys.argv)>3 else 24
keys=list(grid)
for vals in itertools.product(*[grid[k] for k in keys]):
    kw=dict(base); kw.update(dict(zip(keys,vals)))
    r=evaluate(lambda: C.Regler(**kw), n=n, seed0=1000)
    Ts=[x['T_true'] if x['ok_true'] else 30 for x in r['runs']]
    print(dict(zip(keys,vals)), 'score %.2f'%(sum(Ts)/n+r['stats']['T_p90']), r['summary'][:60], flush=True)
