import sys,time,json
sys.path.insert(0,'/home/claude/bob/sim'); sys.path.insert(0,'/home/claude/bob/pico')
from sim import evaluate
import ctrl_bangbang as C
kw=json.loads(sys.argv[1]) if len(sys.argv)>1 else {}
n=int(sys.argv[2]) if len(sys.argv)>2 else 40
r=evaluate(lambda: C.Regler(**kw), n=n, seed0=0)
print(r['summary']); print({k:(v['erfolg'],round(v['T_median'],1)) for k,v in r['stats']['pro_start'].items()})
print('fails', [(x['seed'], x['params']) for x in r['runs'] if not x['ok_true']][:8])
