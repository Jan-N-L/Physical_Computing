# Weitere temporäre Dateien (Sicherung 06.11.2026)

- fruehere_sitzung/: Arbeitsordner der Claude-Sitzung vom 05./06.11. nachts (Kennlinie, Neigung, Waagrecht).
  - data/: phyphox-Messungen (echt), zusätzlich ausgepackt in Claude_Arbeit/messdaten/phyphox/
  - mock/, mock2/: Probeläufe der Skripte mit NACHGEBILDETER Hardware (physik.py). Keine echten Messwerte, auch calib.json und waagrecht_log.csv dort sind simuliert.
  - *.py im Hauptordner: Zwischenstände der Skripte. Massgebend sind Jans Versionen in Scripts/Test/.
  - bt/: Test der Brücke gegen einen nachgebildeten Pico.
- agenten_tmp/: Hilfsskripte der Methoden-Agenten (Bang-Bang, Imitation, MPC, Fuzzy) und tune1.log aus dem ersten, abgebrochenen Durchgang mit dem alten Simulator.
